<?php
	include('../configure/config.php');
	include('../configure/session.php');
	$user = $_SESSION['login_user'];
	$perm = $_SESSION['permission'];
	$last_paid_date = $_SESSION['last_paid_date'];
	$updated_at = date( 'Y-m-d');
	if($_SERVER['REQUEST_METHOD']=='POST'){
		if(isset($_POST['count'])){
			
			$d = explode('-',$_POST['paid_at']);
			$i=0;$n;
			foreach($d as $p){
				$n[$i]=$p;
				$i++;
			}
			$paid_at = '20'.$n[2].'-'.$n[1].'-'.$n[0];
			$paid_at = Date($paid_at);
//-------------------------------------last paid date update------------------------------------------------
			$l_sql = "UPDATE `users` SET `last_paid_date`='$paid_at' WHERE `ID`='$member_id'"; 
			$l_result = $db->query($l_sql) or die("Sql Error :" . $db->error);
			$_SESSION['last_paid_date'] = $paid_at;
//-------------------------------------challan update-----------------------------------------------------
			foreach($_POST['count'] as $upload_record){
				$id = $_POST[$upload_record.'_id_value'];
				$adjustment = $_POST[$upload_record.'_adjustment'];
					$sql = ("UPDATE `challan` SET  `updated_at`='$updated_at', `is_full`='1', `adjustment`='$adjustment',
					`paid`='1', `is_due`='0' WHERE `ID`='$id'"); 
					$result = $db->query($sql) or die("Sql Error :" . $db->error);
			}
			echo '<h3>Selected Challan updated successfully</h3>';
		}
		else{
			echo '<h3>Please Select atleast one row</h3>';
		}
	}
?>
<html>
	<head>
		<link rel="stylesheet" href="../css/main.css">
		<script type="text/javascript" src="../js/jquery-1.4.1.min.js"></script>
		<script> var user = "<?php echo $user;?>";var perm = "<?php echo $perm;?>";var last_paid_date = new Date("<?php echo $last_paid_date;?>");</script>
	</head>
	<body class="content">
	<div >
		<h1 class="heading">Paid on G.R.No</h2><br>
		<div class="button_right">
			<button form="grn_paid_form" class="button button5">Paid</button>
			<h4 id="error">You can't paid on that date</h4>
		</div>
		<label >G.R. No. <input type="text" id="grn" list="grn_list"><datalist id="grn_list"><select>
		<?php
					$sql = "SELECT `G.R.No` FROM `challan` GROUP BY `G.R.No`";
					$result = $db->query($sql) or die('Sql Error: '.$db->error);
					$i=1;
					while($row = mysqli_fetch_array($result)){
						echo '<option>'.$row['G.R.No'].'</option>';
					}
				?>
		</select></datalist></label>
		
		<label>Paid Date: 
			<input type="text" id="paid_at" form="grn_paid_form"name="paid_at" required="" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[012])-[0-9]{2}" placeholder="dd-mm-yy">
		</label> 
	</div>
	<form id="grn_paid_form" action="" method="POST">
		
	<div id="result"></div>
	</form>
	<div align="center"><img align="center" src="../img/loading.gif" id="loading" height="90px"></div>
	</body>
</html>
<script>
$('#error').hide();
$('#result').hide();
$('#loading').hide();
$('#grn').change( function(){
	$('#result').hide();
	$('#loading').show();
	dataString = 'grn='+$(this).val();
	$.ajax({
		type: "POST",
		url: "get/grn_search_paid.php",
		data: dataString,
		cache: false,
		success: function(data)
		{
			$('#loading').hide();
			//console.log(data);
			$('#result').html(data);
			$('#result').show();
		}
	});
});
<?php
	if(!preg_match('/8,9,1,2,3/',$perm)){
?>
	$('#paid_at').change(function(){
		paid_at = new Date("20"+$(this).val().substring(6,8)+"-"+$(this).val().substring(3,5)+"-"+$(this).val().substring(0,2));
		if(+paid_at<+last_paid_date){
			$('button').hide();$('#error').show();
		}
		else{
			$('button').show();$('#error').hide();
		}
	});
<?php
	}
?>
</script>