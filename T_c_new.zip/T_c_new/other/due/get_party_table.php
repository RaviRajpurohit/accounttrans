<?php
	include('../../configure/config.php');
	$try=false;
	if(isset($_POST['partyname'])){
		$party = $_POST['partyname'];
		$paid_at = $_POST['paid_at'];
		$p_sql = "SELECT * FROM `party` WHERE `ID`='$party'";
		$p_result = $db->query($p_sql) or die("Sql Error :" . $db->error);
		$p_row = mysqli_fetch_array($p_result);
		$sql = "SELECT *, DATE_FORMAT(`dateofdeparture`,'%d-%m-%Y') as `dateofdeparture` FROM `challan` WHERE `partyname`='$party' AND `paid`=0 AND `is_due`=1 AND `due_date`='$paid_at'";
		$result = $db->query($sql) or Die('sql Error:'.$db->error);
		echo '<h3>Party: '.$p_row['name'].'</h3>';
		?>
		<table>
			<tr class="mh">
				<th>Challan No</th>
				<th>G.R.No</th>
				<th>Marka</th>
				<th>Nag</th>
				<th>Particular</th>
				<th>Weight</th>
				<th>Freight</th>
				<th>Adjustment</th>
				<th>Paid</th>
				<th>dateofdeparture</th>
				<th>truckno</th>
			</tr>
<?php		
		while($row = mysqli_fetch_array($result)){
			echo '<tr class="j">
				<td><span class="td_right">'.$row['challanNo'].'</span></td>
				<td><span class="td_right">'.$row['G.R.No'].'</span></td>
				<td>'.$row['marka'].'</td>
				<td><span class="td_right">'.$row['nag'].'</span></td>
				<td>'.$row['particular'].'</td>
				<td><span class="td_right">'.$row['weight'].'</span></td>
				<td><span class="td_right">'.$row['freight'].'</span></td>
				<td><span class="td_right">'.$row['adjustment'].'</span></td>
				<td><span class="td_right">'.($row['freight']-$row['adjustment']).'</span></td>
				<td>'.$row['dateofdeparture'].'</td>
				<td>'.$row['truckno'].'</td>
			</tr>';
		}
		echo '</table>';	
	}
?>