<?php
	include('../configure/config.php');
	include('../configure/session.php');
	$user = $_SESSION['login_user'];
	$perm = $_SESSION['permission'];
	$ptrn_update = "/3/";
	$ptrn_paid = "/2/";
	$ptrn_add = "/1/";
	
?>
<html>
	<head>
		<link rel="stylesheet" href="../css/main.css">
		<script type="text/javascript" src="../js/jquery-1.4.1.min.js"></script>
		<script> var user = "<?php echo $user;?>";var perm = "<?php echo $perm;?>";var $connect=[];</script>
	</head>
	<body class="content">
			<h1 class="heading">Payment Information </h1>
			<label>Members: 
			<?php
				if(preg_match('/8,9,1,2,3/',$perm)){
			?>
			
			
			<select id="member">
				<option value="">--select--</option>
			<?php
				$sql = ("SELECT * FROM `users`");
				$result = $db->query($sql) or die("Sql Error :" . $db->error);
				while($row = mysqli_fetch_array($result)){
					echo '<option value="'.$row['ID'].'">'.$row['partyname'].'</option><script>$connect['.$row['ID'].']="'.$row['connected_parties'].'";</script>';
				}
			?>
			</select>
			
			<?php
				}
				else{
					$member_id=$_SESSION['ID'];
					$sql = ("SELECT * FROM `users` WHERE `ID`='$member_id'");
				$result = $db->query($sql) or die("Sql Error :" . $db->error);
				$row = mysqli_fetch_array($result);
					echo '<script>$connect['.$row['ID'].']="'.$row['connected_parties'].'";</script>
					<input type="hidden" id="member" value="'.$row['ID'].'">
					<input type="text" value="'.$row['partyname'].'" readonly>';
				}
			?>
			</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<label>Paid Date: <input type="text" id="paid_at" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[012])-[0-9]{2}" placeholder="dd-mm-yy"></label>
			
			<div class="button_right">
				<button class="button button2" onclick="window.location.href='due/due_challan.php'">Due Challan</button>
			</div>
			
		<div id="main_table" align="center">
		</div>
		<div align="center"><img align="center" src="../img/loading.gif" id="loading" height="90px"></div>
	</body>
</html>



<script>
$('#loading').hide();
$('#member, #paid_at').change(function(){
	var dataString;
	$('#loading').show();
	$('#main_table').hide();
	$id=$('#member').val();
	con=$connect[$id];//console.log(con);
	if($('#paid_at').val()!=''){
		dataString = 'connected_parties='+con+'&paid_at='+$('#paid_at').val();
	}
	else{
		dataString = 'connected_parties='+con;
	}
	$.ajax({
		type: "POST",
		url: "get/get_member_table.php",
		data: dataString,
		cache: false,
		success: function(data)
		{
			$('#main_table').html(data);
			$('#loading').hide();
			$("#main_table").show();
		}
	});
});
</script>