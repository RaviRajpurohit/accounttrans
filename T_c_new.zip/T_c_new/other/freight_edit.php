<?php
	include('../configure/config.php');
	include('../configure/session.php');
	$user = $_SESSION['login_user'];
	$perm = $_SESSION['permission'];
	$member_id=$_SESSION['ID'];
	$ptrn_update = "/3/";
	$ptrn_paid = "/2/";
	$ptrn_add = "/1/";
	$readonly = 'readonly';
	$sql_p = "SELECT *,`party`.`ID` AS `ID` FROM `party` INNER JOIN `users` ON `users`.`connected_parties`=`party`.`address/mobile` AND `users`.`ID`='$member_id'";
	$result_p = $db->query($sql_p) or die('sql error:'.$db->error);
	$row_p = mysqli_fetch_array($result_p);
	$type;$u_p_id=$row_p['ID'];
	
	
	
	if($_SERVER['REQUEST_METHOD']=='POST'){
		if(isset($_POST['count'])){
			foreach($_POST['count'] as $upload_record){
				$id = $_POST[$upload_record.'_id_value'];
				$freight = $_POST[$upload_record.'_freight'];
				$updated_at = date( 'Y-m-d');
				$sql = ("UPDATE `challan` SET `freight`='$freight' WHERE `ID`='$id'");
			}
			$result = $db->query($sql) or die("Sql Error :" . $db->error);
			$msg = 'Selected Challan updated successfully';
		}
		else{
			$msg = 'Please Select atleast one row';
		}
		echo'<h3 style="color:Black;">'.$msg.'</h3>';
	}	
?>
<html>
	<head>
		<link rel="stylesheet" href="../css/main.css">
		<script type="text/javascript" src="../js/jquery-1.4.1.min.js"></script>
		<script> var user = "<?php echo $user;?>";var perm = "<?php echo $perm;?>";var pakka='<?php echo $row_p['type'];?>'; var party_search='<?php echo $u_p_id?>'; var is_view=0;var is_fe=1;</script>
	</head>
	<body class="content">
	<h1 class="heading">You can Edit Challan's Frieght</h1>
	
		<form action="" method="post" onkeypress="return event.keyCode != 13;">
		<button class="button button1" id="update" type="submit">Update Challan</button>
			<input type="hidden" id="upload_record" name="upload_record">
			<table id="main_table">
				<tr class="mh">
					<th>#</th>
					<th>Challan No</th>
					<th>G.R.No</th>
					<th>Marka</th>
					<th>Nag</th>
					<th>particular</th>
					<th>weight</th>
					<th>freight</th>
					<th>partyname</th>
					<th>dateofdeparture</th>
					<th>truckno</th>
				</tr>
				<tr class="fl">
					<th>
						<input type="checkbox" id="all_select" >
					</th>
					<th></th>
					<th><input type="number" id="grn" list="grn_li"></th>
					<?php
						$sql = ("SELECT `G.R.No` FROM `challan` WHERE `paid`=0 AND `is_roundof`=0 AND `is_due`=0 AND `partyname`='$u_p_id' group by `G.R.No`");
						$result = $db->query($sql) or die("Sql Error :" . $db->error);
						echo '<datalist id="grn_li"><select>';
						while($row = mysqli_fetch_array($result)){
							echo '<option>'.$row['G.R.No'].'</option>';
						}
						echo '</select></datalist>';
					?>
					<th><input type="text" id="mrk" list="mrk_li"></th>
					<datalist id="mrk_li"><select id="mrk_li_option">
						<?php
							$sql = ("SELECT `marka` FROM `challan` WHERE `paid`=0 AND `is_roundof`=0 AND `is_due`=0 AND `partyname`='$u_p_id' group by marka");
							$result = $db->query($sql) or die("Sql Error :" . $db->error);
							while($row = mysqli_fetch_array($result)){
								echo '<option>'.$row['marka'].'</option>';
							}
						?>
					</select></datalist>
					<th></th>
					<th></th>
					<th></th>
					<th></th>
					<th><?php echo $row_p['name'];?></th>
					<th><input type="text" id="dod" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[012])-[0-9]{2}" placeholder="dd-mm-yy"></th>
					<th></th>
				</tr>
				<?php
					$p_id=$row_p['ID'];
					$sql = ("SELECT *, DATE_FORMAT(`dateofdeparture`,'%d-%m-%Y') as `dateofdeparture` FROM `challan` WHERE `paid`=0 AND partyname='$p_id' AND `is_roundof`=0 AND `is_due`=0");
					$result = $db->query($sql) or die("Sql Error :" . $db->error);
					$count = 0;
					while($row = mysqli_fetch_array($result)){
						echo '<tr class="j">';
							$count++;
							echo '<td><label><input type="checkbox" id="'.$count.'" name="count[]" value="'.$count.'" >
								<input type="hidden" name="'.$count.'_id_value" value="'.$row['ID'].'">'.$count.'</label></td>
							<td>'.$row['challanNo'].'</td>
							<td>'.$row['G.R.No'].'</td>
							<td>'.$row['marka'].'</td>
							<td>'.$row['nag'].'</td>
							<td>'.$row['particular'].'</td>
							<td>'.$row['weight'].'</td>
							<td><input class="'.$count.'_read" type="text" name="'.$count.'_freight" value="'.$row['freight'].'" '.$readonly.'></td>
							<td>'.$row_p['name'].'</td>
							<td>'.$row['dateofdeparture'].'</td>
							<td>'.$row['truckno'].'</td>
						</tr>';
					}
				?>
			</table>
			<img align="center" src="../img/loading.gif" id="loading" height="90px">
			<script type="text/javascript" src="../js/home.js"></script>
	
		</form>
		
		</body>
</html>



<script>
	
	var count = 0;
	<?php $j=$count;
		while($count>0){
			echo '$("#'.$count.'").click(function(){
				if($(this).is(":checked")){
					$(".'.$count.'_read").attr("readonly",false);
				}
				else{
					$(".'.$count.'_read").attr("readonly",true);
				}
			});';
			$count--;
		}
	?>
	$("#all_select").click(function(){
		$('input:checkbox').not(this).attr('checked', this.checked);
		<?php
			while($j>0){echo '
				if($(this).is(":checked")){
					$(".'.$j.'_read").attr("readonly",false);
				}
				else{
					$(".'.$j.'_read").attr("readonly",true);
				}';
				$j--;
			}
		?>
	});
</script>