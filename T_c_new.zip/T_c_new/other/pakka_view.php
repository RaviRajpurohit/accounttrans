<?php
	include('../configure/config.php');
	include('../configure/session.php');
	$user = $_SESSION['login_user'];
	$perm = $_SESSION['permission'];
	$ptrn_update = "/3/";
	$ptrn_paid = "/2/";
	$ptrn_add = "/1/";
	$readonly=null;
	$challan_id=null;
	$show=0;
	$updated_at=date('y-m-d');
	$sql_pakkachallan=null;
	if(isset($_GET['challan_id'])){
		$challan_id=$_GET['challan_id'];
		
//--------------------------------------pakkachallan check---------------------------------
			$sql_check="SELECT * FROM `pakkachallan` WHERE `challan_id`='$challan_id'";
			$result_check=$db->query($sql_check)or die();
			$count_check=mysqli_num_rows($result_check);
//-----------------------------------------------------------------------------------------
		if($count_check==1){
			$sql_pakkachallan="UPDATE `pakkachallan`,`challan` SET
			`pakkachallan`.`G.R.No`=`challan`.`G.R.No`, `pakkachallan`.`total`=`pakkachallan`.`total`-`pakkachallan`.`freight`+`challan`.`freight`,  `pakkachallan`.`freight`=`challan`.`freight`, `pakkachallan`.`updated_at`='$updated_at' 
			WHERE `pakkachallan`.`challan_id`='$challan_id' AND `pakkachallan`.`challan_id`=`challan`.`ID`";
		}
		else{
			$sql_pakkachallan="INSERT INTO `pakkachallan`(`challan_id`, `G.R.No`, `freight`, `total`, `created_at`, `updated_at`) 
			SELECT `ID`, `G.R.No`, `freight`, `freight`, '$updated_at', '$updated_at' FROM `challan` WHERE `ID`='$challan_id'";
		}
		$result_pakkachallan=$db->query($sql_pakkachallan)or die();
		
		$result=$db->query("SELECT * FROM `pakkachallan` WHERE `challan_id`='$challan_id'")or die();
		$row = mysqli_fetch_array($result);
		if($row['is_print']==1){
			$readonly='readonly';
		}
		if(isset($_GET['show'])){
			if($_GET['show']==1){
				$readonly='readonly';
				$show=1;
			}
			else{
				$show=0;
			}
		}
		
?>
<html>
	<head>
		<link rel="stylesheet" href="../css/main.css">
		<script type="text/javascript" src="../js/jquery-1.4.1.min.js"></script>
		<script> var user = "<?php echo $user;?>";var perm = "<?php echo $perm;?>";</script>
	</head>
	<body class="content">
	<h1 class="heading">Pakka Challan View</h2>
	<h3>Be careful</h3>
			<form method="POST">
				<label>G.R.No: <?php echo $row['G.R.No'];?><input type="hidden" name="G_R_No" value="<?php echo $row['G.R.No'];?>"></label><br><br>
				<label>Sender: <input type="text" name="sender" value="<?php echo $row['sender'];?>"<?php echo $readonly;?>></label>
				<label>Receiver: <input type="text" name="receiver" <?php echo $readonly;?>></label><br><br>
				<label>Freight: <input type="text" name="freight" id="freight" value="<?php echo $row['freight'];?>" <?php echo $readonly;?>></label>
				<label>Commission: <input type="number" name="commission" id="commission" value="<?php echo $row['commission'];?>" <?php echo $readonly;?>></label><br><br>
				<label>Labor: <input type="number" name="labour" id="labour" value="<?php echo $row['labour'];?>" <?php echo $readonly;?>></label>
				<label>Service Tax: <input type="number" name="s_charge" id="s_charge" value="<?php echo $row['serviceTax'];?>" <?php echo $readonly;?>></label><br><br>
				<label>G. Tax: <input type="number" name="g_tax" id="g_tax" value="<?php echo $row['gTax'];?>" <?php echo $readonly;?>></label>
				<label>Cow House: <input type="number" name="goushala" id="goushala" value="<?php echo $row['goushala'];?>" <?php echo $readonly;?>></label><br><br>
				<label>Total: <input type="number" id="total" name="total" value="<?php echo $row['total'];?>" readonly></label><br><br>
				<?php
				if(!$show&&$row['is_print']==0){
					echo'<button id="update" class="button button5">Update</button><button id="conform"  class="button button3">Conform</button>
				<input type="hidden" id="btn" name="btn">';
				}?>
			</form>
				<?php
				if($show||$row['is_print']==1){
					echo'<button id="print"  class="button button2">Print</button>';
				}
			?>
		</div>
		<div id="table">
		</div>
	</body>
</html>
<script>
		freight=+$('#freight').val();
		commission = +$('#commission').val();
		labour = +$('#labour').val();
		s_charge = +$('#s_charge').val();
		g_tax = +$('#g_tax').val();
		goushala = +$('#goushala').val();
		$('#total').val(freight+commission+labour+s_charge+g_tax+goushala);
	$('#update').click(function(){
		$('#btn').val('update');
		$("form").attr("action", "push/pakka_view_value.php?challan_id=<?php echo $challan_id?>");
	});
	$('#conform').click(function(){
		$('#btn').val('conform');
		$("form").attr("action", "push/pakka_view_value.php?challan_id=<?php echo $challan_id?>");
	});
	$('#print').click(function(){
			$('#table').hide();
			dataString = 'id=<?php echo $challan_id?>';console.log(dataString);
			$.ajax({
				type: "POST",
				url: "push/pakka_print.php?user="+user+"&perm="+perm,
				data: dataString,
				cache: false,
				success: function(data)
					{console.log(data);
						$('#table').html(data);
					}
			});
	});
	$('#freight, #commission, #labour, #s_charge, #g_tax, #goushala').bind('keyup change',function(){
		freight=+$('#freight').val();
		commission = +$('#commission').val();
		labour = +$('#labour').val();
		s_charge = +$('#s_charge').val();
		g_tax = +$('#g_tax').val();
		goushala = +$('#goushala').val();
		$('#total').val(freight+commission+labour+s_charge+g_tax+goushala);
	});
</script>
<?php
	}
?>