<?php
	include('../../configure/config.php');
	include('../../configure/session.php');
	$user = $_GET['user'];
	$perm = $_GET['perm'];
	$sql;$date=Date('20y/m/d');
	if($_POST['id']!=''){
		$challan_id=$_POST['id'];
//-------------------------------update query to set is_print and date in pakkachallan and challan table------------------------
		$update_challan="UPDATE `pakkachallan` SET `is_print`=1, `date_of_print`='$date', `updated_at`='$date' WHERE `challan_id`='$challan_id' ";
		$update_pakkachallan="UPDATE `challan` SET `is_print`=1, `updated_at`='$date' WHERE `ID`='$challan_id'";
	
	$result=$db->query($update_challan)or die();
	$result_pakkachallan=$db->query($update_pakkachallan)or die();		//after print setting please uncomment this statement 


//------------------------------------------------------------------------------------------------------------------------------

//------------------------------------------Select Query From pakkachallan Table------------------------------------------------
		$sql="SELECT *,`pakkachallan`.`ID` AS `ID`, `challan`.`freight` AS `freight` FROM `pakkachallan` INNER JOIN `challan` ON `pakkachallan`.`challan_id`= '$challan_id' AND `pakkachallan`.`challan_id`=`challan`.`ID`";
		$result=$db->query($sql) or die('sql Error: '.$db->error);
		$row=mysqli_fetch_array($result);
//------------------------------------------------------------------------------------------------------------------------------

//-----------------------------------------SELECT query From officeData table---------------------------------------------------
		$sql_office="SELECT * FROM `officeData` WHERE `ID`=1";
		$result_office=$db->query($sql_office) or die('sql Error: '.$db->error);
		$row_o=mysqli_fetch_array($result_office);
//------------------------------------------------------------------------------------------------------------------------------
?>
		<div id="report">
			<div align="center">
				<div style="float:left;"><img src="../img/mobile.png" style="float:left;height:35px;"><div style="float:left;"><?php echo $row_o['mobile1'];?><br><?php echo $row_o['mobile2'];?></div></div>
				<div ><small>|| Jai Baba Ramdev Ji ||</small></div>
				<div style="float:right;"><img src="../img/mobile.png" style="float:left;height:35px;"><div style="float:left;"><?php echo $row_o['mobile3'];?></div></div>
			</div>
			<div align="center">
				<h2><?php echo $row_o['companyName'];?></h2>
			</div>
			<div align="center">
				<small><?php echo $row_o['address'];?></small>
			</div>
			<div align="center">
				<label style="float:left;">No.: <?php echo $row['ID'];?></label><label style="float:right;">Date: <?php echo $date;?></label><br>
				<label style="float:left;">M/S: <?php echo $row['marka'];?></label><br>
				<label style="float:left;">From: <?php echo $row['from'];?></label><label style="float:right;">G.R.No.: <?php echo $row['G.R.No'];?></label><br>
			</div>
			<div align="center">
				<div style="float:left;">
					<label></label><br>
					<label></label><br>
					<label>FREIGHT</label><br>
					<label>COMMISSION</label><br>
					<label>LABOUR</label><br>
					<label>G.TAX</label><br>
					<label>COW HOUSE</label><br>
					<label>Aervice Tax</label><br>
					<label>TOTAL</label><br>
				</div>
				<div style="float:left;">
					<label>Amount</label><br>
						<label style="float:right;">Rs.</label><br>
						<label style="float:right;"><?php echo $row['freight'];?></label><br>
						<label style="float:right;"><?php echo $row['commission'];?></label><br>
						<label style="float:right;"><?php echo $row['labour'];?></label><br>
						<label style="float:right;"><?php echo $row['gTax'];?></label><br>
						<label style="float:right;"><?php echo $row['goushala'];?></label><br>
						<label style="float:right;"><?php echo $row['serviceTax'];?></label><br>
						<label style="float:right;"><?php echo $row['total'];?></label><br>
				</div>
				<div style="float:left;">
					<label style="float:right;">Nag: <?php echo $row['nag'];?></label><br>
					<label style="float:right;">Weight: <?php echo $row['weight'];?></label>
				</div>
			</div>
			<div align="center">
				<label style="float:left;">Customer's Sig.</label>
				<label style="float:right;">Signature</label>
			</div>
		</div>
<?php	
	}
?>
<script>
	$(document).ready(function(){
			var divContents = $("#table").html();
			var printWindow = window.open('', '', 'height=600px,width=600px');
			printWindow.document.write('<html><head>');
			printWindow.document.write('<style>  @page {size: 8.3in 5.3in;} @media print{ body{margin:0 auto;width:90%;}}</style>');
			printWindow.document.write('</head><body>');
			printWindow.document.write(divContents);
			printWindow.document.write('</body></html>');
			printWindow.document.close();
			printWindow.print();
		});
</script>