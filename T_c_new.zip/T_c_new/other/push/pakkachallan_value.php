<?php
	include('../../configure/config.php');
	include('../../configure/session.php');
	$user = $_SESSION['login_user'];
	$perm = $_SESSION['permission'];
	$member_id = $_SESSION['ID'];
	$msg=null;
	$sql=null;$is_pakka=null;$dateofdeparture=null;
	$sql_pakkachallan=null;
	if($_SERVER['REQUEST_METHOD']=='POST'){
			if($_POST['fn']=='update_record'){
				if(isset($_POST['count'])){
				foreach($_POST['count'] as $upload_record){
					$id = $_POST[$upload_record.'_id_value'];
//--------------------------------------pakkachallan check---------------------------------
					$sql_check="SELECT * FROM `pakkachallan` WHERE `challan_id`='$id'";
					$result_check=$db->query($sql_check)or die();
					$count_check=mysqli_num_rows($result_check);
//-----------------------------------------------------------------------------------------
					
					$freight = $_POST[$upload_record.'_freight'];
					$partyname = $_POST[$upload_record.'_partyname'];
//--------------------------------------party type---------------------------------------------
				$sql_type = "SELECT `type` FROM `party` WHERE `ID`='$partyname'";
				$result_type=$db->query($sql_type) or die();
				$row_type=mysqli_fetch_array($result_type);
				$is_pakka =$row_type['type'];
//------------------------------------------------------------------------------------------------
					$updated_at = date( 'Y-m-d');
					if(isset($_POST[$upload_record.'_g_r_n'])&&isset($_POST[$upload_record.'_marka'])&&isset($_POST[$upload_record.'_nag'])&&isset($_POST[$upload_record.'_particular'])){
						$GRNo = $_POST[$upload_record.'_g_r_n'];
						$marka = $_POST[$upload_record.'_marka'];
						$nag = $_POST[$upload_record.'_nag'];
						$particular = $_POST[$upload_record.'_particular'];
						$weight = $_POST[$upload_record.'_weight'];
						$sql = ("UPDATE `challan` SET 
						`G.R.No`='$GRNo',`marka`='$marka',`nag`='$nag',`particular`='$particular',`weight`='$weight',`freight`='$freight',`partyname`='$partyname',`updated_at`='$updated_at', `is_pakka`='$is_pakka' 
						WHERE `ID`='$id'");
						if($count_check==1){
							$sql_pakkachallan="UPDATE `pakkachallan` SET
							`G.R.No`='$GRNo', `total`=`total`-`freight`+'$freight',  `freight`='$freight', `updated_at`='$updated_at' 
							WHERE `challan_id`='$id'";
						}
						else{
							$sql_pakkachallan="INSERT INTO `pakkachallan`(`challan_id`, `G.R.No`, `freight`, `total`, `created_at`, `updated_at`) 
							VALUES ('$id', '$GRNo', '$freight', '$freight', '$updated_at', '$updated_at')";
						}
					}
					else{
						$sql = ("UPDATE `challan` SET 
						`freight`='$freight', `partyname`='$partyname', `updated_at`='$updated_at', `is_pakka`='$is_pakka' 
						WHERE `ID`='$id'");
						if($count_check==1){
							$sql_pakkachallan="UPDATE `pakkachallan` SET
							`total`=`total`-`freight`+'$freight',  `freight`='$freight', `updated_at`='$updated_at' 
							WHERE `challan_id`='$id'";
						}
						else{
							$sql_pakkachallan="INSERT INTO `pakkachallan`(`challan_id`, `freight`, `total`, `created_at`, `updated_at`) 
							VALUES ('$id', '$freight', '$freight', '$updated_at', '$updated_at')";
						}
					}
					echo $sql_pakkachallan;
				$result = $db->query($sql) or die("Sql Error :" . $db->error);
				$reulst_pakkachallan=$db->query($sql_pakkachallan)or die();
				}
				$msg = 'Selected Challan updated successfully';}
				else{
					$msg = 'Please Select atleast one row';
				}
			}
			header('Location: ../pakka_challan.php?user='.$user.'&perm='.$perm.'&msg='.$msg);
	}
?>