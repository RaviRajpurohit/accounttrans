<?php
	include('../../configure/config.php');
	include('../../configure/session.php');
	$user = $_GET['user'];
	$perm = $_GET['perm'];
	$selected = $_POST['check'];
//-----------------------------------------SELECT query From officeData table---------------------------------------------------
		$sql_office="SELECT * FROM `officeData` WHERE `ID`=2";
		$result_office=$db->query($sql_office) or die('sql Error: '.$db->error);
		$row_o=mysqli_fetch_array($result_office);
//------------------------------------------------------------------------------------------------------------------------------
?>
<div id="report">
	<div>
		<div align="center">
			<span style="text-align:center;">||Jai Baba Ramdev Ji||</span>
			<div style="float:right;">
				<span>(B) <?php echo $row_o['mobile1']?></span><br>
				<span>(C) <?php echo $row_o['mobile2']?></span><br>
				<span>(R) <?php echo $row_o['mobile3']?></span><br>
			</div>
		</div><br>
		<h2 align="center"><?php echo $row_o['companyName']?></h2>
		<pre align="center" style="font-family:times new roman;">
			<?php echo $row_o['address']?>
		</pre><br>
		<hr>
		<span style="float:left;">Ref.......................</span>
		<span style="float:right;">Date.......................</span><br>
		
	</div><br>
	<table>
		<tr>
			<th>#</th>
			<th>RR Date</th>
			<th>RR No</th>
			<th>G.R.No</th>
			<th>Nag</th>
			<th>Weight</th>
			<th>Freight</th>
		</tr>
		<?php
			$count=0;
			$selected=explode(',',$_POST['check']);
			foreach($selected as $s){
				$count++;
				$sql="SELECT `pakkachallan`.`sender`AS`partyname`,`pakkachallan`.`G.R.No` AS `G.R.No`, `challan`.`nag`AS`nag`, `challan`.`weight`AS`weight`, `pakkachallan`.`freight`, DATE_FORMAT(`pakkachallan`.`created_at`,'%d-%m-%Y') as `created_at`, `pakkachallan`.`ID`AS`ID`  FROM `challan` INNER JOIN `pakkachallan` ON `pakkachallan`.`challan_id`=`challan`.`ID` AND `pakkachallan`.`challan_id`='$s'";
				$result=$db->query($sql)or die();
				$row=mysqli_fetch_array($result);
				echo'<tr>
					<td>'.$count.'</td>
					<td>'.$row['created_at'].'</td>
					<td>'.$row['ID'].'</td>
					<td>'.$row['G.R.No'].'</td>
					<td>'.$row['nag'].'</td>
					<td>'.$row['weight'].'</td>
					<td>'.$row['freight'].'</td>
				<tr>';
				if($count==1){
					echo '<span>To: '.$row['partyname'].'</span><br>';
				}
			}
		?>
	</table>
</div>
<script>
	$(document).ready(function(){
			var divContents = $("#report").html();
			var printWindow = window.open('', '', 'height=600px,width=600px');
			printWindow.document.write('<html><head>');
			printWindow.document.write('<style>   @media print{ body{margin:0 auto;width:90%;}}</style>');
			printWindow.document.write('<link rel="stylesheet" href="../css/main.css"></head><body>');
			printWindow.document.write(divContents);
			printWindow.document.write('</body></html>');
			printWindow.document.close();
			printWindow.print();
		});
</script>