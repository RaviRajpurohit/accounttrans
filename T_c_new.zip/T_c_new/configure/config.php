<?php
	/*Define("HOST","localhost");
	Define("USERNAME","root");
	Define("PASSWORD","");
	Define("DATABASE","newindiatransportcompany");*/
	$db = mysqli_connect('localhost','root','','newindiatransportcompany');
?>